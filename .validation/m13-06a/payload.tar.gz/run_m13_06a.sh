#!/usr/bin/env bash
set -euo pipefail

BASELINE="2386b50bc1110e88f346ddff028cf1e017ad2503"
WORK_BRANCH="work/m13-06a-sync-media-foundation"
PAYLOAD_ROOT="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="${GITHUB_WORKSPACE:?GITHUB_WORKSPACE is required}"
cd "$REPO_ROOT"

git checkout --force "$BASELINE"
git switch -C "$WORK_BRANCH"

python -m pip install -e './backend[dev]'
(cd frontend && npm ci)
(cd e2e && npm ci)

M13_06A_COMMAND=apply-code \
M13_06A_PAYLOAD="$PAYLOAD_ROOT/files" \
python "$PAYLOAD_ROOT/apply_m13_06a.py"
git diff --check

python - <<'PY'
import subprocess
expected = {
    'backend/alembic/versions/0040_channel_sync_media_foundation.py',
    'backend/app/channels/capabilities.py',
    'backend/app/channels/sync.py',
    'backend/app/models/__init__.py',
    'backend/app/models/channel_sync.py',
    'backend/app/repositories/channel_sync.py',
    'backend/tests/test_channel_sync_foundation.py',
    'backend/tests/test_migrations.py',
}
modified = set(subprocess.check_output(
    ['git', 'diff', '--name-only', '2386b50bc1110e88f346ddff028cf1e017ad2503']
).decode().splitlines())
untracked = set(subprocess.check_output(
    ['git', 'ls-files', '--others', '--exclude-standard']
).decode().splitlines())
actual = modified | untracked
assert actual == expected, f'unexpected implementation boundary: {sorted(actual ^ expected)}'
assert not any(path.startswith('backend/app/api/') for path in actual)
assert not any(path.startswith('frontend/') for path in actual)
assert not any(path.endswith(('pyproject.toml', 'package.json', 'package-lock.json')) for path in actual)
print('Implementation files:', len(actual))
PY

(
  cd backend
  python -m ruff check app tests scripts ../scripts
  python -m mypy app
)

(
  cd backend
  python - <<'PY'
import json
from pathlib import Path
from app.main import create_app

committed = json.loads(Path('../frontend/openapi.json').read_text(encoding='utf-8'))
generated = create_app().openapi()
assert committed == generated
assert len(generated['paths']) == 200
encoded = json.dumps(generated)
for forbidden in (
    'ChannelSyncCheckpoint',
    'MediaChannelReference',
    'channel_sync_checkpoints',
    'media_channel_references',
):
    assert forbidden not in encoded
print('OpenAPI semantic equality: PASS')
print('OpenAPI paths:', len(generated['paths']))
PY
)
(
  cd frontend
  npm run gen:api
  git diff --exit-code -- src/lib/api/schema.d.ts openapi.json
)

(
  cd backend
  python -m pytest -q \
    tests/test_channel_sync_foundation.py \
    tests/test_channel_foundation.py \
    tests/test_provider_runtime.py \
    tests/test_migrations.py | tee /tmp/focused-tests.log
)
FOCUSED_TESTS="$(grep -oE '[0-9]+ passed' /tmp/focused-tests.log | tail -1 | awk '{print $1}')"
test -n "$FOCUSED_TESTS"
export FOCUSED_TESTS

(
  cd backend
  python -m pytest -q -p no:cacheprovider --basetemp=.pytest-run-m13-06a | tee /tmp/backend-tests.log
)
BACKEND_TESTS="$(grep -oE '[0-9]+ passed' /tmp/backend-tests.log | tail -1 | awk '{print $1}')"
test -n "$BACKEND_TESTS"
export BACKEND_TESTS

(cd frontend && npm audit --omit=dev --audit-level=high)
(cd frontend && npm run lint)
(cd frontend && npm run typecheck)
(cd frontend && npm test)
(cd frontend && npm run build)
(cd e2e && npm audit --audit-level=high)
(cd e2e && npm run typecheck)

mkdir -p .quality-artifacts .quality-cache
(cd backend && python -m bandit -r app -ll -ii -f json -o ../.quality-artifacts/bandit.json)
(cd backend && python -m pip_audit --strict --progress-spinner off --format cyclonedx-json --output ../.quality-artifacts/backend-sbom.cdx.json .)
WA_QUALITY_DOCKER=docker python scripts/trivy_scan.py source

(
  cd backend
  python -m pytest -q tests/test_migrations.py tests/test_channel_sync_foundation.py
  python - <<'PY'
from alembic.config import Config
from alembic.script import ScriptDirectory

cfg = Config('alembic.ini')
script = ScriptDirectory.from_config(cfg)
assert script.get_current_head() == '0040_channel_sync_media_foundation'
print('Migration head:', script.get_current_head())
PY
)

M13_06A_COMMAND=update-status \
GITHUB_RUN_ID="${GITHUB_RUN_ID:-not-recorded}" \
python "$PAYLOAD_ROOT/apply_m13_06a.py"
git diff --check

python - <<'PY'
import subprocess
expected = {
    'CHANGELOG.md',
    'IMPLEMENTATION_TRACKER.md',
    'MODULE_STATUS.md',
    'PROJECT_STATE.md',
    'ROADMAP.md',
    'VALIDATION_RESULTS.md',
    'backend/alembic/versions/0040_channel_sync_media_foundation.py',
    'backend/app/channels/capabilities.py',
    'backend/app/channels/sync.py',
    'backend/app/models/__init__.py',
    'backend/app/models/channel_sync.py',
    'backend/app/repositories/channel_sync.py',
    'backend/tests/test_channel_sync_foundation.py',
    'backend/tests/test_migrations.py',
}
modified = set(subprocess.check_output(
    ['git', 'diff', '--name-only', '2386b50bc1110e88f346ddff028cf1e017ad2503']
).decode().splitlines())
untracked = set(subprocess.check_output(
    ['git', 'ls-files', '--others', '--exclude-standard']
).decode().splitlines())
actual = modified | untracked
assert actual == expected, f'unexpected final boundary: {sorted(actual ^ expected)}'
assert not any(path.startswith('backend/app/api/') for path in actual)
assert not any(path.startswith('frontend/') for path in actual)
assert not any(path.endswith(('pyproject.toml', 'package.json', 'package-lock.json')) for path in actual)
assert not any('/adr/' in path for path in actual)
print('Final files:', len(actual))
PY

grep -q '0040_channel_sync_media_foundation' PROJECT_STATE.md
grep -q 'WAHA evaluation requires additional evidence' PROJECT_STATE.md
grep -q 'live M13-06 remains blocked' IMPLEMENTATION_TRACKER.md
grep -q 'No provider is certified' CHANGELOG.md
grep -q 'live event ingestion, history execution and media transfer remain blocked by provider certification' ROADMAP.md

git config user.name 'github-actions[bot]'
git config user.email '41898282+github-actions[bot]@users.noreply.github.com'
git add \
  CHANGELOG.md IMPLEMENTATION_TRACKER.md MODULE_STATUS.md PROJECT_STATE.md ROADMAP.md VALIDATION_RESULTS.md \
  backend/alembic/versions/0040_channel_sync_media_foundation.py \
  backend/app/channels/capabilities.py \
  backend/app/channels/sync.py \
  backend/app/models/__init__.py \
  backend/app/models/channel_sync.py \
  backend/app/repositories/channel_sync.py \
  backend/tests/test_channel_sync_foundation.py \
  backend/tests/test_migrations.py
git commit -m 'feat(channels): add sync media persistence foundation'
test "$(git rev-list --count "$BASELINE"..HEAD)" = '1'
git push --force-with-lease origin HEAD:"$WORK_BRANCH"

echo "PRODUCT_COMMIT=$(git rev-parse HEAD)"
git show --stat --oneline --decorate --no-renames HEAD
git status --short
