from __future__ import annotations

import os
import shutil
from pathlib import Path

ROOT = Path.cwd()
PAYLOAD = Path(os.environ.get("M13_06A_PAYLOAD", str(ROOT / ".validation" / "m13-06a" / "files")))


def replace_once(path: str, old: str, new: str) -> None:
    target = ROOT / path
    text = target.read_text(encoding="utf-8")
    if old not in text:
        raise SystemExit(f"expected text not found in {path}: {old[:160]!r}")
    target.write_text(text.replace(old, new, 1), encoding="utf-8")


def insert_after(path: str, marker: str, addition: str) -> None:
    replace_once(path, marker, marker + addition)


def copy_payload() -> None:
    for source in PAYLOAD.rglob("*"):
        if not source.is_file():
            continue
        relative = source.relative_to(PAYLOAD)
        destination = ROOT / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)


def apply_code() -> None:
    copy_payload()

    replace_once(
        "backend/app/channels/capabilities.py",
        '    SESSION_LOGOUT = "session_logout"\n    # Health\n',
        '    SESSION_LOGOUT = "session_logout"\n'
        '    # Provider-neutral bounded synchronization\n'
        '    HISTORY_SYNC = "history_sync"\n'
        '    # Health\n',
    )

    replace_once(
        "backend/app/models/__init__.py",
        "from app.models.channel_session import ChannelSession\n",
        "from app.models.channel_session import ChannelSession\n"
        "from app.models.channel_sync import ChannelSyncCheckpoint, MediaChannelReference\n",
    )
    replace_once(
        "backend/app/models/__init__.py",
        '    "ChannelSession",\n',
        '    "ChannelSession",\n'
        '    "ChannelSyncCheckpoint",\n'
        '    "MediaChannelReference",\n',
    )

    replace_once(
        "backend/tests/test_migrations.py",
        '    "channel_sessions",\n',
        '    "channel_sessions",\n'
        '    "channel_sync_checkpoints",\n'
        '    "media_channel_references",\n',
    )
    replace_once(
        "backend/tests/test_migrations.py",
        '        assert version == "0039_qr_pairing_provider_runtime_foundation"\n',
        '        assert version == "0040_channel_sync_media_foundation"\n',
    )
    replace_once(
        "backend/tests/test_migrations.py",
        '        assert not {"plaintext", "secret_value", "token", "encrypted_payload"} & session_columns\n'
        '        channel_permissions = {\n',
        '        assert not {"plaintext", "secret_value", "token", "encrypted_payload"} & session_columns\n'
        '        checkpoint_columns = {\n'
        '            row[1]\n'
        '            for row in con.execute("PRAGMA table_info(channel_sync_checkpoints)").fetchall()\n'
        '        }\n'
        '        media_reference_columns = {\n'
        '            row[1]\n'
        '            for row in con.execute("PRAGMA table_info(media_channel_references)").fetchall()\n'
        '        }\n'
        '        assert {\n'
        '            "organization_id",\n'
        '            "connection_id",\n'
        '            "endpoint_id",\n'
        '            "job_id",\n'
        '            "sync_type",\n'
        '            "status",\n'
        '            "cursor_json",\n'
        '            "watermark_at",\n'
        '            "cutover_at",\n'
        '            "processed_count",\n'
        '            "failed_count",\n'
        '            "total_count",\n'
        '            "row_version",\n'
        '        } <= checkpoint_columns\n'
        '        assert {\n'
        '            "organization_id",\n'
        '            "media_asset_id",\n'
        '            "endpoint_id",\n'
        '            "provider_media_id",\n'
        '            "upload_state",\n'
        '            "download_state",\n'
        '            "expires_at",\n'
        '            "last_verified_at",\n'
        '            "provider_metadata_json",\n'
        '            "row_version",\n'
        '        } <= media_reference_columns\n'
        '        assert not {"plaintext", "secret_value", "token", "encrypted_payload"} & (\n'
        '            checkpoint_columns | media_reference_columns\n'
        '        )\n'
        '        channel_permissions = {\n',
    )


def update_status() -> None:
    focused = os.environ["FOCUSED_TESTS"]
    backend = os.environ["BACKEND_TESTS"]
    run_id = os.environ.get("GITHUB_RUN_ID", "not-recorded")
    timestamp = "2026-08-05T01:17:00+05:30"

    changelog_entry = f"""
### 2026-08-05 — Provider-neutral Sync & Media Persistence Foundation (M13-06A)

**Added**
- Added the frozen-contract `channel_sync_checkpoints` and `media_channel_references` records with
  organization, connection/endpoint, checkpoint/progress, expiry, transfer-state, Audit and optimistic-
  concurrency facts.
- Added tenant-scoped repositories and provider-neutral sync/media state vocabulary, including the
  existing capability seam's `history_sync` value.
- Added migration `0040_channel_sync_media_foundation` and focused repository, tenant, secret-redaction,
  uniqueness, constraint and migration regressions.

**Preserved**
- No provider is certified. WAHA remains `Requires Additional Evidence`.
- No provider adapter, dependency, live QR pairing, live event ingestion, history job, media transfer,
  queue task, API route, generated contract, frontend behavior or production runtime was added.
- Existing Contact, Conversation, Message, MediaAsset, ChannelAdapter, ChannelConnection,
  ChannelSession, queue, RBAC, tenant, feature-flag and Audit authorities remain unchanged.

**Validated**
- Ruff and strict mypy pass; {focused} focused tests and all {backend} backend tests pass in workflow
  `{run_id}`.
- Migration upgrade/downgrade/re-upgrade passes at `0040_channel_sync_media_foundation`.
- OpenAPI remains semantically unchanged at 200 paths; generated TypeScript and unchanged frontend
  lint, types, tests and production build pass.
- M13-06A reaches `Repository Validated`; all live provider-dependent M13-06 behavior remains blocked
  by certification and host evidence.

"""
    insert_after("CHANGELOG.md", "## [Unreleased]\n", changelog_entry)

    replace_once(
        "IMPLEMENTATION_TRACKER.md",
        "_Last updated: 2026-08-04 · M13-05 QR Pairing & Provider Runtime Foundation is Repository Validated. M13-06 has not started._",
        "_Last updated: 2026-08-05 · M13-06A Provider-neutral Sync & Media Persistence Foundation is Repository Validated. Live provider-dependent M13-06 behavior remains blocked._",
    )
    replace_once(
        "IMPLEMENTATION_TRACKER.md",
        "- **Starting HEAD:** `5d7ea154588418410611de4f568e978c2e3caba9`\n"
        "- **Release:** `1.0.0-rc1`\n"
        "- **Migration/OpenAPI:** `0039_qr_pairing_provider_runtime_foundation` · 200 paths\n"
        "- **Current milestone:** `M13-05 — QR Pairing & Provider Runtime Foundation — REPOSITORY VALIDATED`\n"
        "- **Module 13 completion:** `40%` evidence-based estimate\n"
        "- **Provider selection:** pending; no provider adapter or live provider is registered\n"
        "- **Next milestone:** `M13-06` — not started\n"
        "- **Last synchronized:** `2026-08-04T22:45:00+05:30`\n",
        "- **Starting HEAD:** `2386b50bc1110e88f346ddff028cf1e017ad2503`\n"
        "- **Release:** `1.0.0-rc1`\n"
        "- **Migration/OpenAPI:** `0040_channel_sync_media_foundation` · 200 paths\n"
        "- **Current milestone:** `M13-06A — Provider-neutral Sync & Media Persistence Foundation — REPOSITORY VALIDATED`\n"
        "- **Module 13 completion:** `44%` evidence-based estimate\n"
        "- **Provider selection:** WAHA evaluation requires additional evidence; no provider is certified or registered\n"
        "- **Next milestone:** Provider certification host evidence; live M13-06 remains blocked\n"
        f"- **Last synchronized:** `{timestamp}`\n",
    )
    insert_after(
        "IMPLEMENTATION_TRACKER.md",
        "## Delivered\n\n",
        "### M13-06A Provider-neutral Sync & Media Persistence Foundation\n\n"
        "- Added inert organization-scoped history checkpoints and endpoint-scoped provider media references from the frozen data model.\n"
        "- Added bounded progress/count constraints, opaque non-secret cursor metadata, expiry/verification facts, optimistic concurrency and tenant-scoped repositories.\n"
        "- Extended only the existing capability vocabulary with `history_sync`; no adapter implementation or provider branch exists.\n"
        "- Additive migration `0040_channel_sync_media_foundation`; no API, generated-contract, queue, dependency or frontend source change.\n\n",
    )
    replace_once(
        "IMPLEMENTATION_TRACKER.md",
        "- Ruff PASS.\n"
        "- Strict mypy PASS.\n"
        "- Focused channel/session/runtime/migration suite: 20 PASS.\n"
        "- Full backend suite: 976 PASS in workflow `30933007710`.\n"
        "- Migration validation PASS at `0039_qr_pairing_provider_runtime_foundation`.\n",
        "- Ruff PASS.\n"
        "- Strict mypy PASS.\n"
        f"- Focused channel/sync/media/migration suite: {focused} PASS.\n"
        f"- Full backend suite: {backend} PASS in workflow `{run_id}`.\n"
        "- Migration validation PASS at `0040_channel_sync_media_foundation`.\n",
    )
    replace_once(
        "IMPLEMENTATION_TRACKER.md",
        "QR image generation/scanning, WhatsApp login/protocol, provider adapters, message/history\n"
        "synchronization, sending, incoming webhooks, routing, Inbox/Customer 360/Analytics changes, public\n"
        "runtime/pairing APIs and provider-specific tables are absent.",
        "QR image generation/scanning, WhatsApp login/protocol, provider adapters, live event ingestion,\n"
        "history execution, media transfer/processing, sending, incoming webhooks, routing, Inbox/Customer\n"
        "360/Analytics changes, public runtime/pairing/sync APIs and provider-specific tables are absent.",
    )
    replace_once(
        "IMPLEMENTATION_TRACKER.md",
        "- Provider selection/certification and all M13-06+ inbound/history/media/messaging/operator milestones.",
        "- Provider certification host evidence and all live M13-06 inbound/history/media execution plus later messaging/operator milestones.",
    )
    replace_once(
        "IMPLEMENTATION_TRACKER.md",
        "Do not begin M13-06 or any live QR image/login, provider adapter, messaging, synchronization, webhook,\n"
        "routing, Inbox, Customer 360 or Analytics work. Any architecture or scope deviation requires owner approval.",
        "Do not begin any live M13-06 QR image/login, provider adapter, event ingestion, history execution,\n"
        "media transfer, messaging, webhook, routing, Inbox, Customer 360 or Analytics work until provider\n"
        "certification and separate owner authorization. M13-06A adds persistence only.",
    )

    replace_once(
        "PROJECT_STATE.md",
        "| Current Git HEAD | `HEAD` (M13-05 closeout; resolve after push) |\n"
        "| Current milestone | `M13-05 — QR Pairing & Provider Runtime Foundation — REPOSITORY VALIDATED` |\n"
        "| Current phase | `Provider-neutral runtime registration, pairing state and runtime/session integration delivered; M13-06 unstarted` |\n",
        "| Current Git HEAD | `HEAD` (M13-06A closeout; resolve after push) |\n"
        "| Current milestone | `M13-06A — Provider-neutral Sync & Media Persistence Foundation — REPOSITORY VALIDATED` |\n"
        "| Current phase | `Provider-neutral sync checkpoint/media-reference persistence delivered; all live M13-06 behavior remains certification-blocked` |\n",
    )
    replace_once(
        "PROJECT_STATE.md",
        "| Migration head | `0039_qr_pairing_provider_runtime_foundation` (39 linear revisions) |\n",
        "| Migration head | `0040_channel_sync_media_foundation` (40 linear revisions) |\n",
    )
    replace_once(
        "PROJECT_STATE.md",
        "| Backend evidence | Ruff PASS · strict mypy PASS · 20 focused channel/session/runtime/migration tests PASS · 976 full pytest tests PASS |\n",
        f"| Backend evidence | Ruff PASS · strict mypy PASS · {focused} focused channel/sync/media/migration tests PASS · {backend} full pytest tests PASS |\n",
    )
    replace_once(
        "PROJECT_STATE.md",
        "| M13 contract | ADR-0020 and Design Document 33 remain frozen and authoritative |\n"
        "| Module 13 implementation | `40%` evidence-based estimate: generic contracts, exact identity, persistent connections, session control plane, provider-neutral runtime registry and no-store pairing lifecycle |\n"
        "| QR provider | Not selected; no provider adapter, QR image, WhatsApp protocol or live provider login exists |\n"
        "| Next Module 13 milestone | `M13-06`; not started |\n",
        "| M13 contract | ADR-0020, ADR-0021 and Design Document 33 remain frozen and authoritative |\n"
        "| Module 13 implementation | `44%` evidence-based estimate: M13-01–M13-05 plus provider-neutral sync checkpoint and media-reference persistence |\n"
        "| QR provider | WAHA evaluation requires additional evidence; no provider is certified and no adapter, QR image, protocol or live login exists |\n"
        "| Next Module 13 milestone | Provider certification host evidence; live provider-dependent M13-06 remains blocked |\n",
    )
    replace_once(
        "PROJECT_STATE.md",
        "| Worktree expectation | Sixteen runtime/session/model/repository/service/permission/migration/test files plus six required governance records; no API, generated contract, frontend, provider adapter, messaging, synchronization or M13-06 change |\n"
        "| Last update | `2026-08-04T22:45:00+05:30` (Asia/Kolkata) |\n",
        "| Worktree expectation | Provider-neutral sync/media contracts, two models, tenant repositories, migration/tests and synchronized status records only; no API, frontend, dependency, provider adapter or live execution |\n"
        f"| Last update | `{timestamp}` (Asia/Kolkata) |\n",
    )
    replace_once(
        "PROJECT_STATE.md",
        "## M13-05 delivered provider runtime and pairing foundation\n",
        "## M13-06A delivered provider-neutral sync and media persistence foundation\n\n"
        "- Added `channel_sync_checkpoints` for organization/connection/endpoint-scoped opaque cursor, watermark, cutover, progress, status, error and optimistic-concurrency facts.\n"
        "- Added `media_channel_references` to map existing `MediaAsset` records to endpoint-scoped provider media identifiers with expiry, verification and transfer-state facts.\n"
        "- Added tenant-scoped repositories, non-secret metadata enforcement, bounded list queries and database constraints using the existing model/repository authorities.\n"
        "- No provider runtime, adapter, queue task, history execution, media fetch/upload, event consumer or API was introduced.\n\n"
        "## M13-05 delivered provider runtime and pairing foundation\n",
    )
    replace_once(
        "PROJECT_STATE.md",
        "Target-host commissioning, provider selection/certification, live inbound/history/media, outbound\n"
        "messaging and unified operator experience remain later gated milestones. M13-06 is not started.",
        "Target-host commissioning and provider certification remain mandatory. Live inbound events, history\n"
        "execution, media transfer/processing, outbound messaging and unified operator experience remain\n"
        "later gated milestones. M13-06A is persistence-only and does not satisfy certification.",
    )
    replace_once(
        "PROJECT_STATE.md",
        "Stop after M13-05. Do not begin M13-06, provider selection/backfill, QR image/login, provider adapters,\n"
        "messaging, synchronization, webhook, routing or UI work without a separate explicit owner instruction.",
        "Stop after M13-06A. Do not begin live QR image/login, provider adapters, event ingestion, history\n"
        "execution, media transfer/processing, messaging, webhook, routing or UI work until provider\n"
        "certification and a separate explicit owner instruction.",
    )

    replace_once(
        "MODULE_STATUS.md",
        "Last synchronized: `2026-08-04T22:45:00+05:30`.",
        f"Last synchronized: `{timestamp}`.",
    )
    replace_once(
        "MODULE_STATUS.md",
        "## Module 13 — M13-05 QR Pairing & Provider Runtime Foundation\n",
        "## Module 13 — M13-06A Provider-neutral Sync & Media Persistence Foundation\n\n"
        "- **Milestone status:** `M13-06A — Provider-neutral Sync & Media Persistence Foundation — REPOSITORY VALIDATED`.\n"
        "- **Completion:** `44%` evidence-based estimate.\n"
        "- **Delivered:** provider-neutral history checkpoint and media-reference records, bounded progress/expiry state, tenant-scoped repositories, non-secret metadata validation and migration `0040`.\n"
        "- **Security:** organization predicates, existing foreign authorities, no secret-shaped metadata, uniqueness/check constraints and optimistic row versions fail closed.\n"
        "- **Preserved:** no provider certification, adapter, dependency, QR/login, live event ingestion, history execution, media transfer/processing, queue task, API, generated contract or frontend change.\n"
        "- **Next:** real WAHA host evidence and certification remain required before any live M13-06 behavior.\n\n"
        "## Module 13 — M13-05 QR Pairing & Provider Runtime Foundation\n",
    )
    replace_once(
        "MODULE_STATUS.md",
        "| Enterprise Omnichannel Channel Manager | 40% | M13-00–M13-05 are Repository Validated: provider-neutral contracts, exact Contact identity, persistent connections/secrets, durable session lease/fencing and runtime/pairing control-plane foundation; migrations `0036`–`0039`; unchanged 200-path API | Target-host MySQL/KMS, multi-node runtime commissioning, provider selection/adapters, live QR/login, inbound/history/media, messaging and UI remain pending; M13-06 not started | Existing Contact/Organization/ChannelConnection/ChannelSession/ChannelAdapter/capabilities, FeatureFlag, RBAC/tenant/audit foundations, frozen ADR-0020 and Design Document 33 |",
        "| Enterprise Omnichannel Channel Manager | 44% | M13-00–M13-06A are Repository Validated: provider-neutral contracts, exact Contact identity, persistent connections/secrets, durable session/runtime/pairing control plane, sync checkpoints and media references; migrations `0036`–`0040`; unchanged 200-path API | WAHA host certification, live QR/login, event ingestion, history execution, media transfer, messaging and UI remain pending and blocked | Existing Contact/Organization/ChannelConnection/ChannelSession/ChannelAdapter/MediaAsset/capabilities, FeatureFlag, RBAC/tenant/audit foundations, frozen ADR-0020/0021 and Design Document 33 |",
    )

    validation_section = f"""
## M13-06A Provider-neutral Sync & Media Persistence Foundation

| Validation item | Status | Latest evidence |
|---|---|---|
| Latest Git baseline | PASS | Work starts from `2386b50bc1110e88f346ddff028cf1e017ad2503` on `ui/taste-modernization`. |
| Provider-neutral boundary | PASS | Sync/media state, models and repositories contain no WAHA, Meta or concrete provider branch and no executable provider path. |
| Existing-authority reuse | PASS | References existing ChannelConnection, ChannelEndpoint, JobMetadata and MediaAsset records; no duplicate channel, job, message, media or customer authority exists. |
| Tenant isolation | PASS | Every repository query requires organization scope; foreign organization lookups return no record. |
| Secret handling | PASS | Opaque cursor/provider metadata recursively rejects plaintext credential-shaped fields. |
| Persistence integrity | PASS | Scope/provider identity uniqueness, bounded non-negative progress and transfer-state constraints fail closed. |
| Runtime/certification boundary | PASS | No provider is certified; no adapter, runtime, pairing, event consumer, history executor, media transfer or queue task exists. |
| Ruff / mypy | PASS | Ruff and strict mypy pass. |
| Backend tests | PASS | {focused} focused channel/sync/media/migration tests and all {backend} backend tests pass in workflow `{run_id}`. |
| Frontend gates | PASS | Unchanged frontend passes production audit threshold, ESLint, TypeScript, Vitest and production build. |
| OpenAPI / generated client | PASS | OpenAPI remains semantically unchanged at 200 paths and generated TypeScript has no drift. |
| Migration | PASS | Additive `0040_channel_sync_media_foundation` upgrades, downgrades to `0039`, and upgrades again. |
| Dependency / security boundary | PASS | No dependency changed; Bandit and dependency audit pass. |
| Performance impact | PASS | No API query, worker, provider runtime or frontend bundle path changed; indexed bounded repository queries are the only new executable persistence surface. |
| Host validation | PENDING – Host Machine Validation | MySQL migration/rollback, production-scale query plans, real provider runtime, account/device evidence, monitoring, kill switch, recovery and certification remain unproven. |
| Milestone boundary | PASS | Only provider-neutral persistence/contracts/tests/status records changed; live M13-06 remains blocked. |

"""
    replace_once(
        "VALIDATION_RESULTS.md",
        "Last synchronized: `2026-08-04T22:45:00+05:30`.\n\n## M13-05",
        f"Last synchronized: `{timestamp}`.\n\n{validation_section}## M13-05",
    )

    replace_once(
        "ROADMAP.md",
        "Last synchronized: `2026-08-04T22:45:00+05:30`.",
        f"Last synchronized: `{timestamp}`.",
    )
    replace_once(
        "ROADMAP.md",
        "**Current status: M13-05 — QR Pairing & Provider Runtime Foundation — REPOSITORY VALIDATED**",
        "**Current status: M13-06A — Provider-neutral Sync & Media Persistence Foundation — REPOSITORY VALIDATED**",
    )
    replace_once(
        "ROADMAP.md",
        "ADR-0020 and Design Document 33 remain frozen. M13-01 supplies provider-neutral contracts and\n"
        "registries; M13-02 exact Contact identity; M13-03 persistent connection/endpoint/encrypted-secret\n"
        "records; M13-04 durable session lifecycle/lease/fencing; and M13-05 now supplies provider-neutral\n"
        "runtime registration/discovery/ownership, lifecycle/events/health/capabilities, heartbeat/restart/\n"
        "recovery integration and a no-store pairing state machine. No provider is selected and no live login exists.",
        "ADR-0020, ADR-0021 and Design Document 33 remain frozen. M13-01 supplies provider-neutral contracts\n"
        "and registries; M13-02 exact Contact identity; M13-03 persistent connection/endpoint/encrypted-secret\n"
        "records; M13-04 durable session lifecycle/lease/fencing; M13-05 runtime/pairing control-plane facts;\n"
        "and M13-06A adds inert sync checkpoints and media references. WAHA remains uncertified and no live\n"
        "login, event ingestion, history execution or media transfer exists.",
    )
    replace_once(
        "ROADMAP.md",
        "| M13-06 — QR inbound, history and media | Canonical live events, checkpointed history and existing-media reuse | Blocked by provider certification |",
        "| M13-06 — QR inbound, history and media | Canonical live events, checkpointed history and existing-media reuse | **M13-06A provider-neutral checkpoint/media-reference foundation REPOSITORY VALIDATED**; live event ingestion, history execution and media transfer remain blocked by provider certification |",
    )
    replace_once(
        "ROADMAP.md",
        "Stop after M13-05. No M13-06, provider selection/backfill, live QR image/login, provider adapters,\n"
        "messaging, synchronization, webhook, routing or UI work begins automatically.",
        "Stop after M13-06A. No live QR image/login, provider adapter, event ingestion, history execution,\n"
        "media transfer/processing, messaging, webhook, routing or UI work begins until certification and\n"
        "a separate owner instruction.",
    )


if __name__ == "__main__":
    command = os.environ.get("M13_06A_COMMAND", "apply-code")
    if command == "apply-code":
        apply_code()
    elif command == "update-status":
        update_status()
    else:
        raise SystemExit(f"unknown command: {command}")
